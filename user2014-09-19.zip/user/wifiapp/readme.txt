For information on this example refer to:
docs\examples\CC32xx Out of Box Application.pdf
or
http://processors.wiki.ti.com/index.php/CC32xx_Out_of_Box_Application